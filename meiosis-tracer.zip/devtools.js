/*global chrome*/
chrome.devtools.panels.create("Meiosis",
  "meiosis.png",
  "panel.html",
  function(_panel) {
  }
);
